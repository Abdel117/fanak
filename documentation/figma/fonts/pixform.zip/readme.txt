Pixform is a modular, pixel-based typeface crafted for clarity, character, and code. Built on a grid of precision, it brings retro aesthetics into the modern digital canvas — perfect for interfaces, retro games, and minimalist tech branding.

Free to use for personal and commercial works

Pay what you like:
https://nastark.gumroad.com/l/rekcv

Follow my work on Behnace:
https://www.behance.net/naseer175